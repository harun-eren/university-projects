#include <iostream>
using namespace std;
int main() {
    cout << "HelloWorld" << std::endl;
    return 0;
}