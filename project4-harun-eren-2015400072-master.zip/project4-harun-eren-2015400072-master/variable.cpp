#include "variable.h"


Node:: ~Node(){

}
Variable:: Variable(){
    this->id = 0;
    this->name = "";
    this->value = 0;
    this->derivative = 0;
}
Variable:: Variable(int _id, string _name){
    this->id = _id;
    this->name = _name;
    this->value = 0;
    this->derivative = 0;
}
Variable:: Variable(int _id, string _name, double _value){
    this->id = _id;
    this->name = _name;
    this->value = _value;
    this->derivative = 0;
}
Variable:: ~Variable(){
}
// sets the from pointer
void Variable:: setFrom(Function *_from){
    this->from = _from;
}

// adds the given function to 'to' vector
void Variable:: addTo(Function *_to){
    this->to.push_back(_to);
}

// these functions are inherited features from node class
vector<Node *> Variable:: getIncomings(){
    vector<Node *> result;
    result.push_back((Node *)(from));
    return result;
}
vector<Node *> Variable:: getOutgoings(){
    vector<Node *> result;
    for(auto i : to){
        result.push_back((Node *) (i));
    }
    return result;
}
