//Multiplication, Addition, Substraction, Division, Sine, Cosine, Identity, Tangent,
//ArcCosine, ArcSine, ArcTangent, Exponential, Log, Log10, Power, Sqrt

#include "function.h"
#include "math.h"

Function::Function(int _id, string _name){
    this->name = _name;
    this->id = _id;
}
Function::~Function(){
    delete output;
}
// adds given variable as an input of this function
void Function::addInput(Variable *input){
    inputs.push_back(input);
}

// sets the output variable of the function
void Function::setOutput(Variable *_output){
    output = _output;
}
vector<Node *> Function:: getIncomings(){
    vector<Node *> result;
    for(auto i : inputs){
        result.push_back((Node *) (i));
    }
    return result;
}
vector<Node *> Function:: getOutgoings(){
    vector<Node *> result;
    result.push_back((Node *)(output));
    return result;
}


Multiplication::Multiplication(int _id, string _name)  : Function(_id, _name) {
    this->id = _id;
    this->name = _name;
}
void Multiplication::doForward() {
    output->value = inputs[0]->value * inputs[1]->value;
}
void Multiplication::doBackward() {
    inputs[0]->derivative += inputs[1]->value * output->derivative;
    inputs[1]->derivative += inputs[0]->value * output->derivative;
}

Addition::Addition(int _id, string _name) : Function(_id, _name)  {
    this->id = _id;
    this->name = _name;
}
void Addition::doForward() {
    output->value = inputs[0]->value + inputs[1]->value;
}

void Addition::doBackward() {
    inputs[0]->derivative += output->derivative;
    inputs[1]->derivative += output->derivative;
}
Subtraction::Subtraction(int _id, string _name) : Function(_id, _name)  {
    this->id = _id;
    this->name = _name;
}
void Subtraction::doForward()  {
    output->value = inputs[0]->value - inputs[1]->value;
}
void Subtraction::doBackward() {
    inputs[0]->derivative += output->derivative;
    inputs[1]->derivative += -1 * output->derivative;
}
Division::Division(int _id, string _name)  : Function(_id, _name) {
    this->id = _id;
    this->name = _name;
}
void Division::doBackward() {
    inputs[0]->derivative += output->derivative / inputs[1]->value;
    inputs[1]->derivative += -1 * inputs[0]->value * pow(inputs[1]->value,-2) * output->derivative;
}
void Division::doForward() {
    output->value = inputs[0]->value / inputs[1]->value;
}
Sine::Sine(int _id, string _name) : Function(_id, _name)  {
    this->id = _id;
    this->name = _name;
}
void Sine::doForward() {
    double result = sin(inputs[0]->value);
    output->value = result;
}
void Sine::doBackward() {
    inputs[0]->derivative += output->derivative * cos(inputs[0]->value);
}
Cosine::Cosine(int _id, string _name) : Function(_id, _name)  {
    this->id = _id;
    this->name = _name;
}
void Cosine::doForward() {
    double result = cos(inputs[0]->value);
    output->value = result;
}
void Cosine::doBackward() {
    inputs[0]->derivative += output->derivative * -1 * sin(inputs[0]->value);
}

Identity::Identity(int _id, string _name)  : Function(_id, _name) {
    this->id = _id;
    this->name = _name;
}
void Identity::doForward() {
    output->value = inputs[0]->value;
}
void Identity::doBackward() {
    inputs[0]->derivative += output->derivative;
}
Tangent::Tangent(int _id, string _name) : Function(_id, _name)  {
    this->id = _id;
    this->name = _name;
}
void Tangent::doBackward() {
    inputs[0]->derivative += output->derivative / pow(cos(inputs[0]->value),2);
}
void Tangent::doForward() {
    double result = tan(inputs[0]->value);
    output->value = result;
}
void ArcCosine::doForward() {
    double result = acos(inputs[0]->value);
    output->value = result;
}
ArcCosine::ArcCosine(int _id, string _name) : Function(_id, _name)  {
    this->id = _id;
    this->name = _name;
}
void ArcCosine::doBackward() {
    inputs[0]->derivative += -1 * output->derivative / sqrt(1 - pow(inputs[0]->value,2));
}
ArcSine::ArcSine(int _id, string _name) : Function(_id, _name)  {
    this->id = _id;
    this->name = _name;
}
void ArcSine::doBackward() {
    inputs[0]->derivative += output->derivative / sqrt(1 - pow(inputs[0]->value,2));
}
void ArcSine::doForward() {
    double result = asin(inputs[0]->value);
    output->value = result;
}
ArcTangent::ArcTangent(int _id, string _name) : Function(_id, _name)  {
    this->id = _id;
    this->name = _name;
}
void ArcTangent::doBackward() {
    inputs[0]->derivative += output->derivative / (1 + pow(inputs[0]->value,2));
}
void ArcTangent::doForward() {
    double result = atan(inputs[0]->value);
    output->value = result;
}
Exponential::Exponential(int _id, string _name) : Function(_id, _name) {
    this->id = _id;
    this->name = _name;
}
void Exponential::doForward() {
    double result = exp(inputs[0]->value);
    output->value = result;
}
void Exponential::doBackward() {
    inputs[0]->derivative += output->derivative * output->value;
}
Power::Power(int _id, string _name) : Function(_id, _name)  {
    this->id = _id;
    this->name = _name;
}
void Power::doForward() {
    double result = pow(inputs[0]->value,inputs[1]->value);
    output->value = result;
}
void Power::doBackward() {
    inputs[0]->derivative += output->derivative * inputs[1]->value * pow(inputs[0]->value,inputs[1]->value -1);
    inputs[1]->derivative += output->derivative * pow(inputs[0]->value,inputs[1]->value) * log(inputs[0]->value);
}
Sqrt::Sqrt(int _id, string _name) : Function(_id, _name)  {
    this->id = _id;
    this->name = _name;
}
void Sqrt::doForward() {
    output->value = sqrt(inputs[0]->value) ;
}
void Sqrt::doBackward() {
    inputs[0]->derivative += output->derivative * 0.5 * pow(inputs[0]->value,-0.5);
}
Log::Log(int _id, string _name)  : Function(_id, _name) {
    this->id = _id;
    this->name = _name;
}
void Log::doForward() {
    output->value = log(inputs[0]->value);
}
void Log::doBackward() {
    inputs[0]->derivative += output->derivative / inputs[0]->value;
}
Log10::Log10(int _id, string _name)  : Function(_id, _name) {
    this->id = _id;
    this->name = _name;
}
void Log10::doForward() {
    output->value = log10(inputs[0]->value);
}
void Log10::doBackward() {
    inputs[0]->derivative += output->derivative / inputs[0]->value / log(10);
}