
#include <iostream>
#include <sstream>
#include <algorithm>
#include <map>
#include <fstream>
#include <iterator>
#include <vector>
#include "graph.h"


using namespace std;



template <class Container>
void split1(const string& str, Container& cont)
{
    istringstream iss(str);
    copy(istream_iterator<string>(iss),
         istream_iterator<string>(),
         back_inserter(cont));
}

int main(int argc, char* argv[]) {
    // below reads the input file
    // in your next projects, you will implement that part as well

    if (argc != 5) {
        cout << "Run the code with the following command: ./project4 [input_file] [output_file]" << endl;
        return 1;
    }

    Graph graph = Graph();
    graph.readGraph(argv[1]);

    if (graph.cylic) {
        ofstream s1, s2;
        s1.open(argv[3]);
        s2.open(argv[4]);
        s1 << "ERROR: COMPUTATION GRAPH HAS CYCLE!" << endl;
        s2 << "ERROR: COMPUTATION GRAPH HAS CYCLE!" << endl;
    } else {
            graph.setValues(argv[2],argv[3],argv[4]);

    }

    return 0;
}

