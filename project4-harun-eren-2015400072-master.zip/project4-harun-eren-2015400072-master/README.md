# CMPE250_2017Fall_Project4

Due date: 21.12.2017 23:59

Please check out Project4.pdf for description of the project.

Due date is a strict due date!

## How to compile

In a terminal, call commands:
```
>cmake CMakeLists.txt

>make

OR

>cmake CMakeLists.txt && make

```
Make sure the executable is produced.

Then you can test the project with the command:
```
>./project4 functionDefinitionFile inputValuesFile outputValuesFile derivativeValuesFile
```
