#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <iterator>
#include <unordered_map>
#include "graph.h"
#include <stack>
#include "math.h"
#include <sstream>
#include <algorithm>
#include <iomanip>

using namespace std;

// helper function that checks whether the given string is number or not.
bool isNumber(const string& s)
{
    char* end = 0;
    double val = strtod(s.c_str(), &end);
    return end != s.c_str() && val != HUGE_VAL;
}
template <class Container>
void split1(const string& str, Container& cont)
{
    istringstream iss(str);
    copy(istream_iterator<string>(iss),
         istream_iterator<string>(),
         back_inserter(cont));
}

Graph::Graph(){
    outputNode=0;
    idCount=0;
    inputNum = 0;
}
int Graph::getVariable(string inp){
    int res;
    if( isNumber(inp) ){
        double val = stod(inp.c_str());
        idCount++;
        name[idCount] = inp;
        vars[idCount] = new Variable(idCount, inp, val);
        res = idCount;
        type[idCount] = VARIABLE;
    }
    else{
        if(id.find(inp)==id.end()){
            idCount++;
            id[inp] = idCount;
            name[idCount] = inp;
            vars[idCount] = new Variable(idCount, inp);
            res = idCount;
            type[idCount] = VARIABLE;
        }
        else{
            res = id[inp];
        }
    }
    // printf("%s -> %d\n",inp.c_str(), res);
    return res;
}

int Graph::getFunction(string fnc) {
    idCount++;
    name[idCount] = fnc;
    type[idCount] = FUNCTION;
    Function *f;

    if (fnc.compare("mult") == 0)
        f = new Multiplication(idCount, fnc);
    else if (fnc.compare("add") == 0)
        f = new Addition(idCount, fnc);
    else if (fnc.compare("subs") == 0)
        f = new Subtraction(idCount, fnc);
    else if(fnc.compare("divide")==0)
        f = new Division(idCount, fnc);

    else if(fnc.compare("sin")==0)
        f = new Sine(idCount, fnc);
    else if(fnc.compare("cos")==0)
        f = new Cosine(idCount, fnc);
    else if(fnc.compare("identity")==0)
        f = new Identity(idCount, fnc);
    else if(fnc.compare("tan")==0)
        f = new Tangent(idCount, fnc);
    else if(fnc.compare("acos")==0)
        f = new ArcCosine(idCount, fnc);
    else if(fnc.compare("asin")==0)
        f = new ArcSine(idCount, fnc);
    else if(fnc.compare("atan")==0)
        f = new ArcTangent(idCount, fnc);
    else if(fnc.compare("exp")==0)
        f = new Exponential(idCount, fnc);
    else if(fnc.compare("log")==0)
        f = new Log(idCount, fnc);
    else if(fnc.compare("log10")==0)
        f = new Log10(idCount, fnc);
    else if(fnc.compare("pow")==0)
        f = new Power(idCount, fnc);
    else if(fnc.compare("sqrt")==0)
        f = new Sqrt(idCount, fnc);
    fncs[idCount] = f;
    return idCount;
}

void Graph::addUnaryFunction(string fnc, string inp, string out){

    int fId = getFunction(fnc);
    int inpId = getVariable(inp);
    int outId = getVariable(out);
    fncs[fId]->addInput(vars[inpId]);
    fncs[fId]->setOutput(vars[outId]);

    vars[inpId]->addTo(fncs[fId]);
    vars[outId]->setFrom(fncs[fId]);
}

void Graph::addBinaryFunction(string fnc, string inp1, string inp2, string out){
    int fId = getFunction(fnc);
    int inpId1 = getVariable(inp1);
    int inpId2 = getVariable(inp2);
    int outId = getVariable(out);
    fncs[fId]->addInput(vars[inpId1]);
    fncs[fId]->addInput(vars[inpId2]);
    fncs[fId]->setOutput(vars[outId]);
    vars[inpId1]->addTo(fncs[fId]);
    vars[inpId2]->addTo(fncs[fId]);
    vars[outId]->setFrom(fncs[fId]);

}


void Graph::readGraph(string fileName){
    ifstream infile(fileName);
    string line;
    while(infile.peek() != EOF){
        getline(infile, line);
        vector<string> words;
        split1(line, words);
        string type = words[0];
        if (type.compare("input")==0) {
            int currentId = getVariable(words[1]);
            inputNodes.push_back(currentId);
            inputNum ++;

        } else if (type.compare("output")==0) {
            outputNode = getVariable(words[1]);
            vars[outputNode]->derivative = 1;
        } else if(words.size()==3){
            addUnaryFunction("identity",words[2], words[0]);
        } else if (words.size()==4){
            addUnaryFunction(words[2], words[3], words[0]);
        } else{
            addBinaryFunction(words[2], words[3], words[4], words[0]);
        }
    }
    createTopOrder();
    cylic = isCyclic();
}

void Graph:: setValues(string fileInp, string fileOut, string fileDer){
    ifstream infile(fileInp);
    ofstream s1,s2;
    s1.open(fileOut);
    s2.open(fileDer);
    string line;
    getline(infile, line);
    vector<string> words;
    split1(line, words);
    int n = words.size();
    for(int i=0; i<n; i++){
        s2 << "d" << vars[outputNode]->name << "/d" << words[i] << " ";
    }
    s2 << "\n";
    s1 << vars[outputNode]->name << endl;
    while(infile.peek() != EOF){
        getline(infile, line);
        vector<string> words;
        split1(line, words);
        vector<double> inputValues;
        for(int i=0; i<n; i++){
            inputValues.push_back(stod(words[i]));
        }
        double result = forwardPass(inputValues);
        s1 << setprecision(16) << fixed << result << endl;
        vector<double> derivatives = backwardPass();
        for(auto i : derivatives)
            s2 << setprecision(16) << fixed << i << " ";
        s2 << endl;
        for(auto v : vars){
            v.second->value = 0;
            v.second->derivative = 0;
        }
        vars[outputNode]->derivative =1;
    }
}
void Graph::createTopOrder(){
    int ind [idCount+1];            //keeps indegrees of Nodes
    stack<int> topSort = stack<int>();
    int temp = 0;
    int k = 0;
    for(int i = 1; i<idCount+1; i++)
        if(type[i]==1)
            ind[i] = fncs[i]->getIncomings().size();
        else
            ind[i] = 1;

    for(int i = 0; i<inputNum; i++){
        ind[inputNodes[i]] = 0;
        topSort.push(inputNodes[i]);
    }
    while(!topSort.empty()){
        temp = topSort.top();
        topSort.pop();
        if(type[temp]==VARIABLE){

            for(auto func : vars[temp]->getOutgoings()){
                ind[func->id]--;
                if(func->getIncomings().size()==2 && fncs[func->id]->inputs[0]->id==fncs[func->id]->inputs[1]->id) {

                    ind[func->id]--;
                }
                if(ind[func->id] == 0)
                    topSort.push(func->id);

            }
        } else {
            k++;
            string s = fncs[temp]->name;
            topOrder.push_back(fncs[temp]);
            ind[fncs[temp]->output->id]--;
            topSort.push(fncs[temp]->output->id);
        }
    }
}
bool Graph::isCyclic(){
    int ind [idCount+1];            //keeps visited bool of Nodes
    stack<int> topSort = stack<int>();
    int temp = 0;
    for(int i = 1; i<idCount+1; i++)
        if(type[i]==FUNCTION)
            ind[i]  = fncs[i]->getIncomings().size();
        else
            ind[i] = 1;

    for(int i = 0; i<inputNum; i++){
        ind[inputNodes[i]] = 0;
        topSort.push(inputNodes[i]);
    }
    while(!topSort.empty()){
        temp = topSort.top();
        topSort.pop();
        if(type[temp]==VARIABLE){

            for(auto func : vars[temp]->getOutgoings()){
                ind[func->id]--;
                if(func->getIncomings().size()==2 && fncs[func->id]->inputs[0]->id==fncs[func->id]->inputs[1]->id) {
                    ind[func->id]--;
                }
                if(ind[func->id] == 0)
                    topSort.push(func->id);

            }
        } else {

            if(ind[fncs[temp]->output->id]==0)
                return true;
            ind[fncs[temp]->output->id]--;
            topSort.push(fncs[temp]->output->id);
        }
    }
    return false;
}

double Graph::forwardPass(vector<double> inputValues){
    int size = inputValues.size();
    for(int i = 0; i<size; i++)
        vars[inputNodes[i]]->value = inputValues[i];
    for(auto f : topOrder)
        f->doForward();
    return vars[outputNode]->value;

}

vector<double> Graph::backwardPass(){
    vector<double> derivatives;
    int size = topOrder.size();
    for(int i=size-1; i>=0; i--)
        topOrder[i]->doBackward();
    for(auto d : inputNodes)
        derivatives.push_back(vars[d]->derivative);
    return derivatives;
};

Graph::~Graph(){

}