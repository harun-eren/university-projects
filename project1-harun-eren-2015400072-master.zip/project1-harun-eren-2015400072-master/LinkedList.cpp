#include "LinkedList.h"


LinkedList::LinkedList(){
}

//copy constructor and assignment operator works the same way. 
//(in assignment method we didn't delete anything since the node assignment does it for us) 
//these two methods assign the parameter head node to the instance's head node.
//what is done is basically node assingment. to understand this code, first analyze the given node assignment.
//the node assignment makes the instance's data equal to the parameter's data in terms of value but not memory address.
//it also deep-copies the next node of the parameter, deletes the instance's next and equals instance's next node to
//the node deep-copied and goes on until the tail of the parameter node.

LinkedList:: LinkedList(const LinkedList &list){
    this->length = list.length;
    *(this->tail) = *list.tail;
    *(this->head) = *list.head;
}
LinkedList & LinkedList::operator=(const LinkedList &list){
    this->length = list.length;
    *(this->tail) = *list.tail;
    *(this->head) = *list.head;
    return *this;

}
//finds the last element of the linkedlist and adds new node (whose next pointer is null) to it's next
 void LinkedList::pushTail(Member data){
     Node * newNode = new Node(data);
     if(head){
         Node* temp = head;
         while(temp->next){
             temp = temp->next;
         }
         temp->next = newNode;
         tail = newNode;

     } else {
         head = newNode;
         tail = newNode;
     }
     length++;
}

LinkedList::~LinkedList(){
    if(head)
        delete head;

}



