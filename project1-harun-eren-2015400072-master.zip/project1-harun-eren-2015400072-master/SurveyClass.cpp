#include "SurveyClass.h"
#include <vector>

//this object owns two fields: color and the people whose favourite color is that color. 
//this object is defined to be used to hold both string color and the corresponding value in a vector.
class colorVal {
public:
    string color;
    int value;
    colorVal(string color_){
        this->color = color_;
        value=1;                //when a color is expressed by one's favourite color at the first time,
                                // the number of people whose favourite color is that color is currently 1
    }
};

vector<colorVal> colorData;               // vector of colorVal which owns string color and int value
int vectorSize = colorData.size();        // always holds the size of that vector 
float totalAge;                           // holds the total age of the people attended in given survey


// pushColor method is called when a member expressed his/her favourite color. function adds that color to the array in process:
//if vector is empty, creates corresponding object of colorVal and adds to the array
//if not, the method searchs if that color is expressed someone's fav color before:
//if expressed, method increments the value of that color and ends the method
//if not, it means that color is expressed as fav color the first time, then creates a new colorVal,
//adds to the end of vector.
void pushColor(string color){
    if(vectorSize == 0){
        colorVal temp = colorVal(color);
        colorData.push_back(temp);
        vectorSize++;
        return;
    } else{
        for (int i = 0; i<vectorSize; i++){
            if(colorData[i].color == color) {
                colorData[i].value++;
                return;
            }
        }

        colorVal temp = colorVal(color);
        colorData.push_back(temp);
        vectorSize++;

    }

}
SurveyClass::SurveyClass(){
    members = new LinkedList();
}
SurveyClass::SurveyClass(const SurveyClass &other){
    *(this->members) = LinkedList(*other.members);
}
SurveyClass& SurveyClass::operator=(const SurveyClass& list){
    delete members;
    *(this->members) = *list.members;
    return *this;
}
SurveyClass::~SurveyClass(){
    delete members;
}
void SurveyClass::addMember(const Member& newMember){
    members->pushTail(newMember);
}

//clears totalAge(int) and colorData(vector) for sake of clearity in case of any previous calling of 
//calculateAverageAge and findMostFavouriteColor and change of linkedlist. Then provide the most recent&accurate
//totalAge and colorData vector.
void update(SurveyClass* sc){
    totalAge = 0;
    colorData.empty();
    vectorSize = colorData.size();
    Node* k = sc->members->head;           
    while(k){
        pushColor(k->data.color);          //pushes color to the colorVal array
        totalAge += k->data.age;           //adds the member's age to the total age
        k = k->next;
    }
}

// updates the survey data, calculates the average
float SurveyClass:: calculateAverageAge(){
    update(this);
    float ave = totalAge / members->length;     //average age
    return (int)(ave * 100 + 0.5) /100.0;       //transforms it to the demanded form and returns it
}

string SurveyClass:: findMostFavouriteColor(){
    update(this);
    string s;                                   //holds for the most favourite color
    int a = 0;                                  //holds for the max number of people whose favourite color is same

    for(int i = 0; i < vectorSize; i++) {
        if(colorData[i].value > a) {
            a = colorData[i].value;
            s = colorData[i].color;
        }
    }

    return s;
}

