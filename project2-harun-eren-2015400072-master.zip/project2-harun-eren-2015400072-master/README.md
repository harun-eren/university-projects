# CMPE250_2017Fall_Project2

Due date: 23.11.2017 23:59

Please check out Project2.pdf for description of the project.

Due date is a strict due date!

## How to compile

In a terminal, call commands:
```
>cmake CMakeLists.txt

>make

OR

>cmake CMakeLists.txt && make

```
Make sure the executable is produced.

Then you can test the project with the command:
```
>./project2 inputFile outputFile
```
