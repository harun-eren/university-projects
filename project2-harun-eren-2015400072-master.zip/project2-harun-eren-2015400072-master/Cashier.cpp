//
// Created by COMPUTER on 22.11.2017.
//

#include "Cashier.h"



    Cashier::Cashier(){
        busyTime = 0;
        available = true;
    }
    void Cashier:: add(double orderTime){
        busyTime = busyTime + orderTime;
        available = false;
    }
    Cashier::~Cashier(){
    }


