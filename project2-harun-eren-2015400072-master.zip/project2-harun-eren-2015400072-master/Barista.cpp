//
// Created by COMPUTER on 22.11.2017.
//

#include "Barista.h"


Barista::Barista(){
    busyTime = 0;
    available = true;
    max = 0;
}
void Barista:: add(double brew){
    busyTime = busyTime + brew;
    available = false;
}
Barista::~Barista(){
}
