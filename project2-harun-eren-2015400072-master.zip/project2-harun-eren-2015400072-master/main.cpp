

#include <iostream>
#include <sstream>
#include <algorithm>
#include <fstream>
#include <iterator>
#include <vector>
#include "CoffeeShop.h"

using namespace std;



template <class Container>
void split1(const string& str, Container& cont)
{
    istringstream iss(str);
    copy(istream_iterator<string>(iss),
         istream_iterator<string>(),
         back_inserter(cont));
}

int main(int argc, char* argv[]) {
    // below reads the input file
    // in your next projects, you will implement that part as well


    if (argc != 3) {
        cout << "Run the code with the following command: ./project1 [input_file] [output_file]" << endl;
        return 1;
    }

    cout << "input file: " << argv[1] << endl;
    cout << "output file: " << argv[2] << endl;


    ifstream infile(argv[1]);
    freopen (argv[2],"w",stdout);
    string line;
    vector<string> input;
    // process first line
    getline(infile, line);
    int N = stoi(line);
    getline(infile, line);
    int M =  stoi(line);
    CoffeeShop Starbucks = CoffeeShop(N, M);
    float f0,f1,f2,f3;
    for (int i = 0; i < M; i++) {
        getline(infile, line);
        vector<string> words;
        split1(line, words);
        f0 = stof(words[0]);
        f1 = stof(words[1]);
        f2 = stof(words[2]);
        f3 = stof(words[3]);
        Starbucks.customers1[i]= Customer(f0, f1, f2, f3);
        Starbucks.customers2[i]= Customer(f0, f1, f2, f3);


    }

    Starbucks.firstModel();
    //totalTime1
    //maxCashierQ1
    //maxBaristaQ
    //  N lines: busyTime/totalTime1 of cashiers1[]
    //  N/3 lines: busyTime/totalTime1 of baristas1[]
    //  M lines:     time - arrivalTime of customers1[]

    printf("%.2lf",Starbucks.totalTime1);
    printf("\n");
    printf("%d",Starbucks.maxCashierQ1);
    printf("\n");
    printf("%d",Starbucks.maxBaristaQ);
    printf("\n");
    for(int i=0 ; i<N; i++){
        printf("%.2lf",Starbucks.cashiers1[i].busyTime/Starbucks.totalTime1);
        printf("\n");
    }
    for(int i=0; i<N/3; i++){
        printf("%.2lf",Starbucks.baristas1[i].busyTime/Starbucks.totalTime1);
        printf("\n");
    }
    for(int i=0; i<M; i++){
        printf("%.2lf",Starbucks.turnaround1.top().time);
        Starbucks.turnaround1.pop();
        //printf("%.2lf",Starbucks.customers1[i].time - Starbucks.customers1[i].arrival);
        printf("\n");
    }
    printf("\n");
    Starbucks.secondModel();
    //totalTime2
    //maxCashierQ2
    //  N/3 lines:  max of baristas2[]
    //  N lines: busyTime/totalTime2 of cashiers2[]
    //  N/3 lines: busyTime/totalTime2 of baristas2[]
    //  M lines:     time - arrivalTime of customers2[]
    printf("%.2lf",Starbucks.totalTime2);
    printf("\n");
    printf("%d",Starbucks.maxCashierQ2);
    printf("\n");
    for(int i=0; i<N/3; i++){
        printf("%d",Starbucks.baristas2[i].max);
        printf("\n");
    }
    for(int i=0 ; i<N; i++){
        printf("%.2lf",Starbucks.cashiers2[i].busyTime/Starbucks.totalTime2);
        printf("\n");
    }
    for(int i=0; i<N/3; i++){
        printf("%.2lf",Starbucks.baristas2[i].busyTime/Starbucks.totalTime2);
        printf("\n");
    }
    for(int i=0; i<M; i++){
        printf("%.2lf",Starbucks.turnaround2.top().time);
        Starbucks.turnaround2.pop();
        printf("\n");
    }
    fclose(stdout);
}
