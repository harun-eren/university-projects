//
// Created by COMPUTER on 21.11.2017.
//

#ifndef ASSIGNMENT2_COFFEESHOP_H
#define ASSIGNMENT2_COFFEESHOP_H
#include "Cashier.h"
#include "Customer.h"
#include "Barista.h"
#include <vector>
#include <queue>

using namespace std;

//tells priority queue to sort customers by prices of their orders
struct compareByPrice {
    bool  operator()(Customer& c1, Customer& c2){
        return c1.price > c2.price;
    }
};
struct compareByArrival {
    bool operator()(Customer& c1, Customer& c2){
        return c1.arrival>c2.arrival;
    }
};
//tells priority queue to sort customers by the time their act is
//this is the base of stimulating events chronologically
struct compareByTime {
    bool operator()(Customer &c1, Customer &c2) {
        return c1.time > c2.time;
    }
};
class CoffeeShop{
public:
    int N, M;

    //fields for 1st model
    double totalTime1;
    Customer* customers1 ;
    Cashier* cashiers1 ;
    Barista* baristas1 ;
    priority_queue<Customer, vector<Customer>, compareByTime> timeline1; //keeps all events of customers for 1st model
    queue<Customer> cashierQueue1;           //keeps customers waiting for any cashier to be available
    priority_queue<Customer, vector<Customer>, compareByPrice> baristaQ1; //keeps customers waiting for any
    // barista to be available
    int maxCashierQ1, maxBaristaQ;    //holds max size of cashier and barista queues
    priority_queue<Customer, vector<Customer>, compareByArrival> turnaround1;

    //fields for 2nd model
    double totalTime2;
    Customer* customers2 ;
    Cashier* cashiers2;
    Barista* baristas2;
    priority_queue<Customer, vector<Customer>, compareByTime> timeline2; //timeline for 2nd model
    queue<Customer> cashierQueue2;                    //holds cashier queue for second model
    int maxCashierQ2;
    priority_queue<Customer, vector<Customer>, compareByArrival> turnaround2;



    CoffeeShop(int N_, int M_);

    // if( step = 0 )
    // if  all of cashiers are full, push it to the cashierqueue
    // if not, adds orderTime to cashier's busy time.
    // change status of the customer to 1

    //if( step == 1 )
    //  pops it, change it to 2, removes the cashier's pointer,checks if CashierQueue not empty,
    // then take that customer, care about that!
    // checks barista queue empty? if so, try to place it to barista's array.
    //
    //   if added, place it to timeline1. if no added, add it to queue.
    //   if not empty, add it to queue. don't add that to timeline while just in queue.
    //
    //
    //
    //  if (step = 2 )
    //  removes the customer from the barista, pops from timeline finds required data, takes the top of queue
    //
    //
    void firstModel ();
    void secondModel ();


};

#endif //ASSIGNMENT2_COFFEESHOP_H
