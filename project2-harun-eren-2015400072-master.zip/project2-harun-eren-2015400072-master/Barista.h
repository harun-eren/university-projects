//
// Created by COMPUTER on 22.11.2017.
//

#ifndef Barista_H
#define Barista_H
#include "Customer.h"
#include <vector>
#include <queue>
using namespace std;

//this struct will tell Barista priority queues to sort orders by their prices
struct compareByPrice1 {
    bool  operator()(Customer& c1, Customer& c2){
        return c1.price < c2.price;
    }
};

class Barista {
public:
    double busyTime;
    bool available;
    priority_queue<Customer, vector<Customer>, compareByPrice1> sQueue; //holds for barista queues of 2nd model
    int max;                              //holds for max size of barista queue of 2nd model
    Barista();
    //barista takes the next customer by this method
    void add(double brew);
    ~Barista();
};


#endif