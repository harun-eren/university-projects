//
// Created by COMPUTER on 21.11.2017.
//

#include "Customer.h"

/*
    float arrival;
    float orderTime;
    float brew;
    float price;
    float time;
    int step;
    int sCashierID;
    int sBaristaID;*/
    Customer::Customer(){
        arrival, orderTime, brew, price, time = 0;
        step = 0;
        sCashierID =0;
        sBaristaID=0;
    }
    Customer::Customer (double arrival_, double order_time, double brew_, double price_){
        arrival = arrival_;
        orderTime = order_time;
        brew = brew_;
        price = price_;
        time = arrival_;
        step = 0;
        sCashierID = 0;
        sBaristaID = 0;
    }
    Customer::Customer (double arrival_, double order_time, double brew_, double price_, int step_, double time_,
    int cashier, int barista){
        arrival = arrival_;
        orderTime = order_time;
        brew = brew_;
        price = price_;
        time = time_;
        step = step_;
        sCashierID = cashier;
        sBaristaID = barista;


}
    Customer::~Customer(){

    }

