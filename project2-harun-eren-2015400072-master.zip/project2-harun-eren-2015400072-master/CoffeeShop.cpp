#include <iostream>
#include <sstream>
#include <algorithm>
#include <fstream>
#include <iterator>
#include <queue>
#include "CoffeeShop.h"
using namespace std;


    CoffeeShop::CoffeeShop(int N_, int M_){
        N = N_;
        M = M_;
        totalTime1 = 0;
        totalTime2 = 0;
        maxCashierQ1 = 0;
        maxCashierQ2 = 0;
        maxBaristaQ = 0;
        customers1 = new Customer[M];
        cashiers1 = new Cashier [N];
        baristas1 = new Barista [N/3];
        customers2 = new Customer [M];
        cashiers2 = new Cashier [N];
        baristas2 = new Barista[N/3];

    }



    // if( status = 0 )
    // isFull -> traces all cashiers :
    // true, add it to the cashier queue
    // if false, place customer to the first cashier being available
    // and return index of it OR returns index of the first being available.
    // adds orderTime to cashier's busy time.
    // change status of the customer to 1

    //if( status == 1 )
    //  pops it, change it to 2, removes the cashier's pointer,checks if CashierQueue not empty,
    // then take that customer, care about that!
    // checks barista queue empty? if so, try to place it to barista's array.
    //
    //   if added, place it to timeline1. if no added, add it to queue.
    //   if not empty, add it to queue. don't add that to timeline while just in queue.
    //
    //
    //
    //  if (status = 2 )
    //  removes the customer from the barista, pops from timeline finds required data, takes the top of queue
    //
    //

    void CoffeeShop:: firstModel (){
       const Customer*  co;
        for(int i = 0; i<M; i++){
            timeline1.push(customers1[i]);
        }
        while(timeline1.size()!=0){

            co = &timeline1.top();
            //Customer (float arrival_, float order_time, float brew_, float price_, int step_, float time_)
            Customer * processing = new Customer(co->arrival, co->orderTime,co->brew,co->price,co->step,co->time
            ,co->sCashierID,co->sBaristaID);

            timeline1.pop();

            if(processing->step == 0) {
                bool noCashierAva = true;

                for (int i = 0; i < N; i++) {
                    if (cashiers1[i].available) {
                        noCashierAva = false;
                        break;
                    }
                }
                //cout << "noCashierAva : " << noCashierAva << endl;
                if (noCashierAva){
                    cashierQueue1.push(*processing);
                    if(maxCashierQ1 < cashierQueue1.size())
                        maxCashierQ1 = cashierQueue1.size();
                } else{
                    for(int i = 0; i<N; i++)
                        if(cashiers1[i].available){
                            cashiers1[i].add(processing->orderTime);
                            processing->sCashierID = i;
                            i=N+1;
                        }
                    processing->step = 1;

                    processing->time = processing->time + processing->orderTime;

                    timeline1.push(*processing);
                }

            } else if (processing->step == 1){
                cashiers1[processing->sCashierID].available = true;
                if(cashierQueue1.size()>0){

                    Customer temp = cashierQueue1.front();
                    cashierQueue1.pop();

                    temp.time = processing->time ;
                    timeline1.push(temp);
                }
                if( baristaQ1.size()>0 ){
                    baristaQ1.push(*processing);

                    if(maxBaristaQ < baristaQ1.size())
                        maxBaristaQ = baristaQ1.size();
                } else{

                    bool noBaristaAva = true;
                    for(int i=0; i<N/3; i++){
                        if(baristas1[i].available){
                            noBaristaAva = false;
                            break;
                        }
                    }
                    if(noBaristaAva){

                        baristaQ1.push(*processing);
                        if(maxBaristaQ < baristaQ1.size())
                            maxBaristaQ = baristaQ1.size();
                    } else {
                        for (int i = 0; i < N / 3; i++)
                            if (baristas1[i].available) {

                                baristas1[i].add(processing->brew);
                                processing->sBaristaID = i;
                                i = N;
                            }
                        processing->step = 2;

                        processing->time = processing-> time + processing->brew;

                        timeline1.push(*processing);
                    }
                }


            } else if (processing->step == 2){

                baristas1[processing->sBaristaID].available = true;
                if(baristaQ1.size()>0) {

                    Customer *temp = (Customer *) malloc(sizeof(Customer));
                    *temp = baristaQ1.top();
                    baristaQ1.pop();
                    temp->time = processing->time + temp->brew;
                    baristas1[processing->sBaristaID].add(temp->brew);
                    temp->step=2;
                    timeline1.push(*temp);
                }
                if(timeline1.size()==0)
                    totalTime1 = processing->time;
                processing->time = processing->time - processing->arrival;
                turnaround1.push(*processing);
            }
        }


    }



    void CoffeeShop:: secondModel (){
        const Customer*  co;
        for(int i = 0; i<M; i++){
            timeline2.push(customers1[i]);
        }
        while(timeline2.size()!=0){
            co = &timeline2.top();
            timeline2.pop();
            Customer * processing = new Customer(co->arrival, co->orderTime,co->brew,co->price,co->step,co->time
                    ,co->sCashierID,co->sBaristaID);

            if(processing->step == 0){

                bool noCashierAva = true;

                for (int i = 0; i < N; i++) {
                    if (cashiers2[i].available) {
                        noCashierAva = false;
                        break;
                    }
                }
                if (noCashierAva){
                    cashierQueue2.push(*processing);
                    if(maxCashierQ2 < cashierQueue2.size())
                        maxCashierQ2 = cashierQueue2.size();

                } else{
                    for(int i = 0; i<N; i++)
                        if(cashiers2[i].available){
                            cashiers2[i].add(processing->orderTime);
                            processing->sCashierID = i;
                            i = N;
                        }
                    processing->step = 1;
                    processing->time = processing->time + processing->orderTime;
                    timeline2.push(*processing);
                }

            } else if (processing->step == 1){
                cashiers2[processing->sCashierID].available = true;
                int n = processing->sCashierID / 3;
                if(cashierQueue2.size()>0){
                    Customer* temp = &cashierQueue2.front();
                    cashierQueue2.pop();
                    temp->time = processing->time;
                    timeline2.push(*temp);
                }
                if( baristas2[n].sQueue.size()>0 ){
                    baristas2[n].sQueue.push(*processing);
                    if(baristas2[n].max < baristas2[n].sQueue.size())
                        baristas2[n].max = baristas2[n].sQueue.size();
                } else{
                    if(!baristas2[n].available){
                        baristas2[n].sQueue.push(*processing);
                        if(baristas2[n].max < baristas2[n].sQueue.size())
                            baristas2[n].max = baristas2[n].sQueue.size();
                    } else {
                        for (int i = 0; i < N / 3; i++)
                            if (baristas2[i].available) {
                                baristas2[i].add(processing->brew);
                                processing->sBaristaID = i;
                                i = N;
                            }
                        processing->step = 2;
                        processing->time = processing->time + processing->brew;
                        timeline2.push(*processing);
                    }
                }


            } else if (processing->step == 2){
                int m = processing->sCashierID / 3;
                baristas2[processing->sBaristaID].available = true;
                if(baristas2[m].sQueue.size()>0) {
                    Customer *temp = (Customer *) malloc(sizeof(Customer));
                    *temp = baristas2[m].sQueue.top();
                    baristas2[m].sQueue.pop();
                    temp->time = processing->time + temp->brew;
                    baristas1[processing->sBaristaID].add(temp->brew);
                    temp->step = 2;
                    timeline2.push(*temp);

                }
                if(timeline2.size()==0) {
                    totalTime2 = processing->time;
                }

                processing->time = processing->time - processing->arrival;
                turnaround2.push(*processing);

            }
        }

    }



