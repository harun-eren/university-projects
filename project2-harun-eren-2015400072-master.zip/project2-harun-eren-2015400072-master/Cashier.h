//
// Created by COMPUTER on 22.11.2017.
//

#ifndef Cashier_H
#define Cashier_H


class Cashier{
public:
    double busyTime;
    bool available;
    Cashier();
    //the cashier takes the next customer by this method
    void add(double orderTime);
    ~Cashier();

};


#endif //ASSIGNMENT2_CASHIER_H
