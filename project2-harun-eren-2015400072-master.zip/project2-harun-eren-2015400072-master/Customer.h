//
// Created by COMPUTER on 21.11.2017.
//

#ifndef Customer_H
#define Customer_H


class Customer{
public:

    double arrival;
    double orderTime;
    double brew;
    double price;
    double time;
    int step;      //on which step the customer is : 0 arrived 1 ordering 2 coffee not prepared yet
    int sCashierID;
    int sBaristaID;
    Customer();

    Customer (double arrival_, double order_time, double brew_, double price_);
    Customer (double arrival_, double order_time, double brew_, double price_, int step_, double time_, int cashier,
    int barista);
    ~Customer();
};


#endif //ASSİGNMENT2_CUSTOMER_H
