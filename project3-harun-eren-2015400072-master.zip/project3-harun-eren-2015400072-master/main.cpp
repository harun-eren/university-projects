
#include <iostream>
#include <sstream>
#include <algorithm>
#include <map>
#include <fstream>
#include <iterator>
#include <vector>
#include "Graph.h"

using namespace std;



template <class Container>
void split1(const string& str, Container& cont)
{
    istringstream iss(str);
    copy(istream_iterator<string>(iss),
         istream_iterator<string>(),
         back_inserter(cont));
}

int main(int argc, char* argv[]) {
    // below reads the input file
    // in your next projects, you will implement that part as well

    if (argc != 3) {
        cout << "Run the code with the following command: ./project1 [input_file] [output_file]" << endl;
        return 1;
    }

    cout << "input file: " << argv[1] << endl;
    cout << "output file: " << argv[2] << endl;

    cout << "hey" << endl;
    ifstream infile(argv[1]);
    freopen (argv[2],"w",stdout);
    string line;
    vector<string> input;
    // process first line
    getline(infile, line);
    vector<string> words;
    split1(line, words);
    int n,m,p,k;
    n = stoi(words[0]);
    m = stoi(words[1]);
    p = stoi(words[2]);
    k = stoi(words[3]);

    Graph middleEast = Graph(n,p);
    int w,q,r;
    for (int i = 0; i < k; i++) {
        getline(infile, line);
        vector<string> words;
        split1(line, words);
        w = stoi(words[0]);
        q = stoi(words[1]);
        for(int j=0; j<q; j++){
            r = stoi(words[2+j]);
            middleEast.allJewelers.insert(r-1);
            int temp = middleEast.jewelers[w-1] | 1<<(r-1);
            middleEast.jewelers[w-1] = temp;
        }
        cout << i << endl;


    }
    int v,u,t,s,z;
    for(int i=0; i<m; i++){
        getline(infile, line);
        vector<string> words;
        split1(line, words);
        v = stoi(words[0]);
        u = stoi(words[1]);
        t = stoi(words[2]);
        s = stoi(words[3]);
        bool isPossible = true;
        int thieves = 0;
        for(int j=0 ; j<s; j++){
            z = stoi(words[4+j]);
            isPossible = isPossible && middleEast.allJewelers.count(z-1);
            thieves = thieves | 1 << (z-1);
        }
        if(isPossible){
            Road newRoad1 = Road(t, u-1);
            newRoad1.thieves = thieves;
            middleEast.edges[v-1].push_back(newRoad1);
            Road newRoad2 = Road(t, v-1);
            middleEast.edges[u-1].push_back(newRoad2);
        }
    }
    middleEast.processGraph();
    string solution = middleEast.getShortest();
    cout << solution << endl;
    fclose(stdout);
}
