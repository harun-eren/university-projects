//
// Created by COMPUTER on 08.12.2017.
//

#ifndef PROJECT3_GRAPH_H
#define PROJECT3_GRAPH_H
#include <set>
#include <map>
#include <list>
#include "Road.h"
#include <iostream>
#include <queue>
#include <stack>
using namespace std;

typedef pair<int, int> iPair;

class Graph {
public:
    set<int> allJewelers;             //keeps all types of coins in the graph

    //map<int,vector<int>>  townList;     //list of towns by jewelers they have
    //map<int,vector<int>>  jewelerList;  //list of jewelers by towns
    int N;                            //number of towns, keeps Tehran's id
    int P;

    Graph(int n, int p);
    void processGraph();
    string getShortest();    //finds the path between given two towns

    vector<vector<Road>> edges;      //holds roads in which given town is start point
    vector<vector<iPair>> space;
    vector<int> jewelers;
};


#endif //PROJECT3_GRAPH_H
