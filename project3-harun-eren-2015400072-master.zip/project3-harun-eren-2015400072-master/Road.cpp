//
// Created by COMPUTER on 08.12.2017.
//

#include "Road.h"

Road::Road(){
     time = 0;
     to = 0;
    thieves = 0;
}
Road::Road(int t, int goesTo){
    time = t;
    to = goesTo;
    thieves = 0;
}
Road::~Road(){}