//
// Created by COMPUTER on 08.12.2017.
//

#ifndef PROJECT3_ROAD_H
#define PROJECT3_ROAD_H
#include <vector>
using namespace std;
class Town;

class Road {
public:
    int time;           //time needed to pass that road
    int to;             //the town the road goes to

    int thieves;
    vector<int> thieves1;     //array of those thieves


    Road();
    Road(int t, int goesTo);
    ~Road();

};


#endif //PROJECT3_ROAD_H
