//
// Created by COMPUTER on 08.12.2017.
//

#include "Graph.h"
# define INF 0x3f3f3f3f

    Graph::Graph(int n, int p) {     //initializes the graph
        int j = 1;
        for (int i=0; i<p; i++)
            j = j*2;

        this->N = n;
        this->P = p;

        for(int i=0; i<N; i++){
            jewelers.push_back(0);
            edges.emplace_back(vector<Road>());
            for(int k=0 ; k<j; k++){
                space.emplace_back(vector<iPair>());
            }
        }

}

void Graph::processGraph(){           //creates 2^p * N size graph to represent the situation which depends on Ali Baba's state
                                         //if Ali Baba gains a coin that he didn't have before, he travels to corresponding node
    int allCases = 1;                       // in different graph.
    for(int i=0; i<P; i++){
        allCases = allCases*2;
    }
    for(int i=0; i<allCases; i++){

        for(int n=0; n<N; n++) {

            vector<Road> *roads = new vector<Road>();
            if (!edges[n].empty()) {
                *roads = edges[n];
                for (auto it : *roads) {
                    bool pass = ((i & it.thieves) == it.thieves);

                    if (pass) {
                        int index =  (jewelers[it.to] | jewelers[n])*N + it.to ;
                        space[i*N+n].emplace_back(make_pair(it.time, index));
                        }
                    }
                }
            delete roads;
            }
        }


    for(int q = 0; q<allCases; q++)
        space[q*N+N-1].emplace_back(make_pair(0,allCases*N));



}
                                                                
string Graph::getShortest(){                                        //finds the shortest path of new conducted graph

    string path = "";
    int allCases = 1;
    for(int i=0; i<P; i++)
        allCases = allCases*2;
    set<int> known;                 //set of visited nodes in all spaces of graph
    vector<int> dist (allCases * N + 1,INF);
    vector<int> prev (allCases * N + 1,-1);
    priority_queue<iPair> pq;
    int startIndex = jewelers[0] ;
    pq.push(make_pair(0, startIndex));
    dist[startIndex] = 0;

    while(!pq.empty()){
        int current = pq.top().second;
        pq.pop();
        if(known.count(current)!=0)
            known.insert(current);
                if (!space[current].empty()) {

                    for (auto road : space[current]) {

                        int edge = road.first;
                        int adjacent = road.second;

                        if (dist[adjacent] > dist[current] + edge) {
                            prev[adjacent] = current;
                            dist[adjacent] = dist[current] + edge;
                            pq.push(make_pair(dist[adjacent], adjacent));
                        }

                    }
                }


    }


    if(prev[allCases * N]==-1)
        return "-1";
    else {
        stack<int> stack;
        int previous = prev[allCases * N];
        while(previous!=-1){
            stack.push(previous);
            previous = prev[previous];
        }
        while(!stack.empty()) {
            int town = stack.top();
            stack.pop();
            town = town%N + 1;
            string town1 = to_string(town);
            path = path + town1 + " ";
        }
        return path;
    }

}
